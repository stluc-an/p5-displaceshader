Adapted from 
https://github.com/aferriss/p5jsShaderExamples/tree/gh-pages/4_image-effects/4-7_displacement-map 